function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.message.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.loaded.add(function () {
          var currentTickCount = 0;
          scene.update.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["toomo", "result", "doutei_toomo", "itteq", "nensyuu_2man", "virus", "zyousoubu", "inu", "report", "wassyoi"]
        });
        var time = 60; // 制限時間

        if (param.sessionParameter.totalTimeLimit) {
          time = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


        g.game.vars.gameState = {
          score: 0
        }; // タイトルシーン

        var titleScene = new g.Scene({
          game: g.game,
          assetIds: ["title"]
        });
        titleScene.loaded.add(function () {
          // タイトル画面
          var titleSprite = new g.Sprite({
            scene: titleScene,
            src: titleScene.assets["title"]
          });
          titleScene.append(titleSprite);
          titleScene.setTimeout(function () {
            // 5秒待つ
            scene.loaded.add(function () {
              // ここからゲーム内容を記述します
              time -= 5; // 背景

              var backgruondFilledRect = new g.FilledRect({
                scene: scene,
                width: g.game.width,
                height: g.game.height,
                cssColor: "white"
              });
              scene.append(backgruondFilledRect); // フォントの生成

              var font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.SansSerif,
                size: 48
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: scene,
                text: "スコア: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black"
              });
              scene.append(scoreLabel); // スコア変更用関数

              var setScore = function setScore() {
                scoreLabel.text = "\u30B9\u30B3\u30A2: " + g.game.vars.gameState.score + " \u70B9";
                scoreLabel.invalidate();
              }; // 残り時間表示用ラベル


              var timeLabel = new g.Label({
                scene: scene,
                text: "残り時間: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black",
                x: 0.7 * g.game.width
              });
              scene.append(timeLabel); // プレイヤー

              var playerSprite = new g.Sprite({
                scene: scene,
                src: scene.assets["toomo"]
              });
              playerSprite.x = 100;
              playerSprite.y = 100;
              playerSprite.modified();
              scene.append(playerSprite); // ジャンプする関数

              var jump = function jump() {
                // 音
                scene.assets["wassyoi"].play();
                var v0 = 10; // 初速

                var gravity = 0.9; // 重力加速度

                var ground = playerSprite.y; // プレイヤーのいちにするといい感じ

                var jumpTime = 0;

                var playerPosFunc = function playerPosFunc() {
                  // 公式
                  var calc = 0.5 * gravity * jumpTime * jumpTime - v0 * jumpTime + ground; // 下で回避するやつ絶対いるので対策

                  if (playerSprite.height + calc < g.game.height && calc > 0) {
                    playerSprite.y = calc;
                  } else if (calc < 0) {
                    playerSprite.y = 0;
                  }

                  jumpTime++;
                  playerSprite.modified();
                };

                playerSprite.update.remove(playerPosFunc);
                playerSprite.update.add(playerPosFunc);
              }; // 画面を押したとき


              scene.pointDownCapture.add(function () {
                if (time >= 5) {
                  jump(); // ジャンプする
                }
              }); // 加点

              scene.update.add(function () {
                if (time >= 5) {
                  g.game.vars.gameState.score++;
                  setScore();
                }
              }); // ランダムで物を置く

              var imgList = ["doutei_toomo", "itteq", "nensyuu_2man", "virus", "zyousoubu", "report", "inu"]; // 物生成関数

              var createMono = function createMono() {
                var random = g.game.random.get(0, imgList.length - 1);

                if (time >= 5) {
                  var monoSprite_1 = new g.Sprite({
                    scene: scene,
                    src: scene.assets[imgList[random]],
                    tag: imgList[random] // タグに名前入れとく

                  });
                  monoSprite_1.x = g.game.width + monoSprite_1.width;
                  monoSprite_1.y = g.game.random.get(0, 300);
                  scene.append(monoSprite_1);
                  monoSprite_1.update.add(function () {
                    if (time >= 5) {
                      monoSprite_1.x -= 10;

                      if (g.Collision.intersectAreas(monoSprite_1, playerSprite)) {
                        monoSprite_1.destroy();
                        var assetId = monoSprite_1.tag;

                        if (assetId === "inu") {
                          // 犬の時は回復
                          g.game.vars.gameState.score += 50;
                        } else {
                          g.game.vars.gameState.score -= 50;
                        }

                        setScore();
                      }
                    }
                  });
                }
              };

              scene.setInterval(function () {
                createMono();

                if (time - 5 <= 40) {
                  scene.setTimeout(function () {
                    createMono();
                  }, g.game.random.get(500, 1000)); // ずらすため
                }
              }, 1000);

              var updateHandler = function updateHandler() {
                if (time <= 0) {
                  // RPGアツマール環境であればランキングを表示します
                  if (param.isAtsumaru) {
                    var boardId_1 = 1;
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId_1, g.game.vars.gameState.score).then(function () {
                      window.RPGAtsumaru.experimental.scoreboards.display(boardId_1);
                    });
                  }

                  scene.update.remove(updateHandler); // カウントダウンを止めるためにこのイベントハンドラを削除します
                }

                if (time <= 5) {
                  // 終了
                  var resultSprite = new g.Sprite({
                    scene: scene,
                    src: scene.assets["result"]
                  });
                  scene.append(resultSprite);
                } // カウントダウン処理


                time -= 1 / g.game.fps;
                timeLabel.text = "残り時間: " + Math.ceil(time - 5) + " 秒";
                timeLabel.invalidate();
              };

              scene.update.add(updateHandler); // ここまでゲーム内容を記述します
            });
            g.game.pushScene(scene);
          }, 5000);
        });
        g.game.pushScene(titleScene);
      }

      exports.main = main;
    }, {}]
  }, {}, [1])(1);
});